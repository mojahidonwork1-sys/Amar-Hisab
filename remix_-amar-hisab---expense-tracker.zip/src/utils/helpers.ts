import { Transaction } from './types';

export function formatCurrency(amount: number): string {
  // Uses Bangladeshi Taka formatting (South Asian numbering system)
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount).replace('BDT', '৳');
}

export function exportToCSV(transactions: Transaction[], filename: string) {
  if (transactions.length === 0) return;
  
  // Define columns
  const headers = ['Date', 'Type', 'Category', 'Amount (BDT)', 'Note'];
  
  // Format rows
  const rows = transactions.map(t => [
    t.date,
    t.type.toUpperCase(),
    t.category,
    t.amount,
    t.note || ''
  ]);
  
  // Create CSV string
  const csvContent = [
    headers.join(','),
    ...rows.map(e => e.join(','))
  ].join('\n');
  
  // Create blob and download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
