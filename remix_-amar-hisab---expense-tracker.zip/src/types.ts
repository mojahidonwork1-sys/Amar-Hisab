export type Category = 
  | 'Food' 
  | 'Rent' 
  | 'Shopping' 
  | 'Transport' 
  | 'Bills' 
  | 'Salary' 
  | 'Freelance'
  | 'Entertainment'
  | 'Other';

export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  category: Category;
  date: string;
  note: string;
}

export interface UserProfile {
  name: string;
}

export interface Budget {
  category: Category;
  amount: number;
}
