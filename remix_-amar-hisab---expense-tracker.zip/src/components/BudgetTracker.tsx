import React, { useState } from 'react';
import { Transaction, Budget, Category } from '../types';
import { formatCurrency } from '../utils/helpers';
import { cn } from '../utils/cn';
import { Target, PlusCircle, Trash2, AlertTriangle, Info } from 'lucide-react';

const EXPENSE_CATEGORIES: Category[] = ['Food', 'Rent', 'Shopping', 'Transport', 'Bills', 'Entertainment', 'Other'];

interface BudgetTrackerProps {
  transactions: Transaction[];
  budgets: Budget[];
  onSetBudget: (budget: Budget) => void;
  onDeleteBudget: (category: Category) => void;
}

export function BudgetTracker({ transactions, budgets, onSetBudget, onDeleteBudget }: BudgetTrackerProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category>('Food');
  const [amount, setAmount] = useState('');

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || isNaN(Number(amount))) return;
    onSetBudget({ category: selectedCategory, amount: Number(amount) });
    setIsAdding(false);
    setAmount('');
  };

  // Calculate current month's expenses per category
  const currentMonthExpenses = transactions.filter(t => {
    if (t.type !== 'expense') return false;
    const d = new Date(t.date);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  }).reduce((acc, t) => {
    acc[t.category] = (acc[t.category] || 0) + t.amount;
    return acc;
  }, {} as Record<string, number>);

  const unbudgetedCategories = EXPENSE_CATEGORIES.filter(c => !budgets.find(b => b.category === c));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-xl font-bold text-slate-900">Monthly Budgets</h2>
        {!isAdding && unbudgetedCategories.length > 0 && (
          <button 
            onClick={() => setIsAdding(true)}
            className="px-4 py-2 bg-emerald-900 text-white rounded-xl font-semibold shadow-lg shadow-emerald-900/20 flex items-center gap-2 text-sm"
          >
            <PlusCircle className="w-4 h-4" />
            New Budget
          </button>
        )}
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-[32px] border border-emerald-200 shadow-sm animate-in fade-in duration-300">
          <h3 className="text-md font-bold mb-4 text-emerald-900">Set Category Budget</h3>
          <form onSubmit={handleSave} className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-xs font-bold text-slate-500 mb-1">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value as Category)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 rounded-xl px-4 py-3 outline-none transition-all font-semibold"
              >
                {unbudgetedCategories.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-xs font-bold text-slate-500 mb-1">Monthly Limit (৳)</label>
              <input
                type="number"
                required
                min="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 rounded-xl px-4 py-3 outline-none transition-all font-semibold"
                placeholder="e.g. 5000"
              />
            </div>
            <div className="flex items-end gap-2 shrink-0">
              <button 
                type="button" 
                onClick={() => setIsAdding(false)}
                className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button 
                type="submit"
                className="py-3 px-6 bg-emerald-900 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-lg shadow-emerald-900/20 transition-all"
              >
                Save
              </button>
            </div>
          </form>
        </div>
      )}

      {budgets.length === 0 && !isAdding ? (
        <div className="bg-slate-50 p-8 rounded-[32px] border border-slate-200 text-center flex flex-col items-center">
          <div className="w-16 h-16 bg-slate-200 rounded-2xl flex items-center justify-center text-slate-400 mb-4">
            <Target className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">No budgets set</h3>
          <p className="text-slate-500 mt-2 max-w-sm mb-6">Create monthly limits for your spending categories to stay on top of your finances.</p>
          <button 
            onClick={() => setIsAdding(true)}
            className="px-6 py-3 bg-emerald-900 text-white rounded-xl font-bold shadow-lg shadow-emerald-900/20 flex items-center gap-2"
          >
            <PlusCircle className="w-5 h-5" />
            Set your first budget
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {budgets.map((budget) => {
            const spent = currentMonthExpenses[budget.category] || 0;
            const percentage = Math.min((spent / budget.amount) * 100, 100);
            
            let statusStyle = "bg-emerald-500";
            let alertStyle = null;
            let iconStyle = "bg-emerald-100 text-emerald-600";
            
            if (percentage >= 100) {
              statusStyle = "bg-rose-500";
              alertStyle = "text-rose-600 bg-rose-50 border-rose-200";
              iconStyle = "bg-rose-100 text-rose-600";
            } else if (percentage >= 80) {
              statusStyle = "bg-amber-500";
              alertStyle = "text-amber-700 bg-amber-50 border-amber-200";
              iconStyle = "bg-amber-100 text-amber-600";
            }

            return (
              <div key={budget.category} className="bg-white p-6 rounded-[32px] border border-slate-200 shadow-sm flex flex-col relative group">
                <button 
                  onClick={() => onDeleteBudget(budget.category)}
                  className="absolute top-4 right-4 p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                  aria-label="Remove Budget"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-3 mb-6">
                  <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center font-bold", iconStyle)}>
                    <Target className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900">{budget.category}</h3>
                    <p className="text-xs text-slate-500 font-medium">Monthly Limit</p>
                  </div>
                </div>

                <div className="flex justify-between items-end mb-2">
                  <div>
                    <span className="text-sm font-bold text-slate-900">{formatCurrency(spent)}</span>
                    <span className="text-xs text-slate-500"> spent</span>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-bold text-slate-400">Total {formatCurrency(budget.amount)}</span>
                  </div>
                </div>
                
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mb-4">
                  <div 
                    className={cn("h-full rounded-full transition-all duration-1000", statusStyle)} 
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>

                {alertStyle && (
                  <div className={cn("mt-auto flex items-start gap-2 p-3 rounded-xl border text-xs font-semibold", alertStyle)}>
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    {percentage >= 100 
                      ? "You've exceeded your budget for this category!" 
                      : `You've used ${percentage.toFixed(0)}% of your budget. Be careful!`
                    }
                  </div>
                )}
                {!alertStyle && (
                  <div className="mt-auto flex items-start gap-2 p-3 rounded-xl border border-transparent text-xs font-semibold text-slate-400">
                    <Info className="w-4 h-4 shrink-0 mt-0.5 opacity-50" />
                    {100 - percentage > 0 
                      ? `${(100 - percentage).toFixed(0)}% remaining. You are on track.`
                      : ""
                    }
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
