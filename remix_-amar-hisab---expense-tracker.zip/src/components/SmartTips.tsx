import { useState, useEffect } from 'react';
import { Transaction } from '../types';
import { GoogleGenAI } from '@google/genai';
import { Sparkles, Loader2, Info } from 'lucide-react';

interface SmartTipsProps {
  transactions: Transaction[];
}

export function SmartTips({ transactions }: SmartTipsProps) {
  const [tips, setTips] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const generateTips = async () => {
    if (transactions.length < 3) {
      setTips("আপনার লেনদেনের পরিমাণ কম। আরও কিছু লেনদেন যোগ করুন যাতে আমি সঠিক পরামর্শ দিতে পারি।");
      return;
    }

    setLoading(true);
    setError('');

    try {
      const expenses = transactions
        .filter(t => t.type === 'expense')
        .reduce((acc, t) => {
          acc[t.category] = (acc[t.category] || 0) + t.amount;
          return acc;
        }, {} as Record<string, number>);

      const totalIncome = transactions.filter(t => t.type === 'income').reduce((a, t) => a + t.amount, 0);
      const totalExpense = transactions.filter(t => t.type === 'expense').reduce((a, t) => a + t.amount, 0);

      const promptData = `
        Total Income: ৳${totalIncome}
        Total Expense: ৳${totalExpense}
        Category-wise Expenses: ${JSON.stringify(expenses)}
      `;

      // Initialize AI (Note: Requires process.env.GEMINI_API_KEY from Vite definition)
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: promptData,
        config: {
          systemInstruction: `You are an expert financial advisor for Bangladeshi users. 
          Respond ONLY in clear, natural Bengali language. 
          Provide 2-3 short, modern, and practical expense control tips based on the user's spending habits provided.
          Be encouraging but point out if they are spending too much on non-essentials. 
          Do not use bullet points or * marks, just write a brief friendly paragraph. Keep it to max 50 words.`
        }
      });

      if (response.text) {
        setTips(response.text.trim());
      } else {
        throw new Error('No response text');
      }

    } catch (err) {
      console.error(err);
      setError('পরামর্শ তৈরি করতে সমস্যা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Generate tips on load if there are transactions
    if (transactions.length > 0 && !tips) {
      generateTips();
    }
  }, []);

  return (
    <div className="bg-emerald-50 rounded-[32px] border border-emerald-100 p-6 flex flex-col md:flex-row items-start md:items-center gap-4 relative">
      <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex flex-shrink-0 items-center justify-center text-white shadow-lg">
        <Sparkles className="w-6 h-6" />
      </div>
      <div className="flex-1">
        <div className="flex items-center justify-between mb-1">
          <h4 className="text-sm font-bold text-emerald-900">Smart AI Tip (Bengali)</h4>
          <button 
            onClick={generateTips} 
            disabled={loading}
            className="text-xs text-emerald-700 hover:text-emerald-900 bg-white/50 px-2 py-1 object-right rounded-lg transition-colors font-medium border border-emerald-200"
          >
            {loading ? 'Thinking...' : 'Refresh'}
          </button>
        </div>
        <div>
          {loading ? (
            <div className="flex items-center gap-2 text-emerald-700 py-2">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-xs font-medium">Generating insight...</span>
            </div>
          ) : error ? (
            <div className="flex items-start gap-2 text-rose-600/80 text-xs font-medium mt-1">
              <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
              <p>{error}</p>
            </div>
          ) : tips ? (
            <p className="text-xs text-emerald-800 font-medium italic leading-relaxed">
              "{tips}"
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
}
