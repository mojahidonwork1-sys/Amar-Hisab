import React from 'react';
import { LayoutDashboard, PieChart, History, Download, User as UserIcon, WalletCards } from 'lucide-react';
import { cn } from '../utils/cn';

interface LayoutProps {
  children: React.ReactNode;
  activeView: 'dashboard' | 'history' | 'analytics' | 'budgets';
  setActiveView: (view: 'dashboard' | 'history' | 'analytics' | 'budgets') => void;
  userName: string;
  onEditProfile: () => void;
  onExport: () => void;
}

export function Layout({ children, activeView, setActiveView, userName, onEditProfile, onExport }: LayoutProps) {
  return (
    <div className="min-h-screen pb-24 md:pb-0 md:pl-20 lg:pl-64 flex flex-col transition-all">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col fixed top-0 left-0 h-screen w-20 lg:w-64 bg-white border-r border-slate-200 z-40">
        <div className="p-6 flex items-center justify-center lg:justify-start gap-3">
          <div className="w-10 h-10 lg:w-14 lg:h-14 rounded-2xl bg-emerald-900 flex items-center justify-center text-white font-bold text-xl">
            {userName ? userName.charAt(0).toUpperCase() : 'M'}
          </div>
          <span className="hidden lg:block font-bold text-xl text-emerald-950 tracking-tight">Amar Hisab</span>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-8">
          <NavItem 
            icon={<LayoutDashboard />} 
            label="Dashboard" 
            isActive={activeView === 'dashboard'} 
            onClick={() => setActiveView('dashboard')} 
          />
          <NavItem 
            icon={<WalletCards />} 
            label="Budgets" 
            isActive={activeView === 'budgets'} 
            onClick={() => setActiveView('budgets')} 
          />
          <NavItem 
            icon={<History />} 
            label="History" 
            isActive={activeView === 'history'} 
            onClick={() => setActiveView('history')} 
          />
          <NavItem 
            icon={<PieChart />} 
            label="Analytics" 
            isActive={activeView === 'analytics'} 
            onClick={() => setActiveView('analytics')} 
          />
        </nav>

        <div className="p-4 mt-auto space-y-2">
            <button 
                onClick={onExport}
                className="w-full flex items-center justify-center lg:justify-start gap-3 p-3 text-emerald-700 hover:bg-white/40 rounded-xl transition-colors font-medium group"
              >
                <Download className="w-5 h-5 group-hover:text-emerald-900" />
                <span className="hidden lg:block">Export Data</span>
            </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 sm:p-6 lg:p-8 animate-in fade-in duration-500">
        {/* Header Options */}
        <header className="flex justify-between items-center bg-white/70 backdrop-blur-md p-6 rounded-3xl border border-white shadow-sm mb-8">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-emerald-950">
                {activeView === 'dashboard' && 'Overview'}
                {activeView === 'budgets' && 'Budgets'}
                {activeView === 'history' && 'Transactions'}
                {activeView === 'analytics' && 'Analytics'}
              </h1>
              <p className="text-emerald-800/60 mt-1">
                {new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
              </p>
            </div>

            {/* User Profile */}
            <button onClick={onEditProfile} className="bg-white p-2 pl-4 pr-5 rounded-full flex items-center gap-3 hover:bg-slate-50 transition-all cursor-pointer shadow-sm border border-slate-200 group">
                <div className="text-right hidden sm:block">
                    <p className="text-sm text-slate-500 font-medium">Hello,</p>
                    <p className="text-sm font-semibold text-emerald-950 leading-tight">{userName || 'User'}</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 bg-gradient-to-br from-emerald-100 to-teal-200 shadow-inner group-hover:scale-105 transition-transform">
                    <UserIcon className="w-5 h-5" />
                </div>
            </button>
        </header>
        
        {children}
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-4 left-4 right-4 bg-white border border-slate-200 rounded-2xl flex justify-around p-2 z-40 shadow-xl">
        <MobileNavItem 
            icon={<LayoutDashboard />} 
            label="Home" 
            isActive={activeView === 'dashboard'} 
            onClick={() => setActiveView('dashboard')} 
          />
          <MobileNavItem 
            icon={<WalletCards />} 
            label="Budgets" 
            isActive={activeView === 'budgets'} 
            onClick={() => setActiveView('budgets')} 
          />
          <MobileNavItem 
            icon={<History />} 
            label="History" 
            isActive={activeView === 'history'} 
            onClick={() => setActiveView('history')} 
          />
          <MobileNavItem 
            icon={<PieChart />} 
            label="Stats" 
            isActive={activeView === 'analytics'} 
            onClick={() => setActiveView('analytics')} 
          />
      </nav>
    </div>
  );
}

function NavItem({ icon, label, isActive, onClick }: { icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center justify-center lg:justify-start gap-4 p-3 rounded-xl transition-all duration-200 group",
        isActive 
          ? "bg-emerald-900 shadow-lg shadow-emerald-900/20 text-white" 
          : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
      )}
    >
      <div className={cn("transition-transform", isActive ? "scale-110" : "group-hover:scale-110")}>
        {icon}
      </div>
      <span className="hidden lg:block font-medium">{label}</span>
    </button>
  );
}

function MobileNavItem({ icon, label, isActive, onClick }: { icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void }) {
    return (
      <button
        onClick={onClick}
        className={cn(
          "flex flex-col items-center justify-center p-2 rounded-xl min-w-[72px] transition-colors duration-200",
          isActive 
            ? "text-emerald-900 bg-emerald-50" 
            : "text-slate-500 hover:text-slate-800"
        )}
      >
        <div className={cn("mb-1 transition-transform", isActive ? "scale-110 text-emerald-900" : "")}>
          {icon}
        </div>
        <span className="text-[10px] font-medium">{label}</span>
      </button>
    );
  }
