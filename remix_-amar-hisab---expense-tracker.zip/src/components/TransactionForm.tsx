import React, { useState } from 'react';
import { Transaction, Category } from '../types';
import { PlusCircle, Loader2 } from 'lucide-react';
import { cn } from '../utils/cn';

interface TransactionFormProps {
  onAdd: (transaction: Transaction) => void;
  onCancel: () => void;
}

const CATEGORIES: Category[] = ['Food', 'Rent', 'Shopping', 'Transport', 'Bills', 'Salary', 'Freelance', 'Entertainment', 'Other'];

export function TransactionForm({ onAdd, onCancel }: TransactionFormProps) {
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<Category>('Food');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [note, setNote] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || isNaN(Number(amount))) return;
    
    onAdd({
      id: crypto.randomUUID(),
      type,
      amount: Number(amount),
      category,
      date,
      note,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <div className="bg-white rounded-[32px] p-8 w-full max-w-md shadow-2xl animate-in fade-in zoom-in duration-200 border border-slate-200">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Add Transaction</h2>
        
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Type Toggle */}
          <div className="flex p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              className={cn("flex-1 py-2 text-sm font-bold rounded-lg transition-colors", type === 'income' ? "bg-white text-emerald-600 shadow" : "text-slate-500 hover:bg-slate-200")}
              onClick={() => setType('income')}
            >
              Income
            </button>
            <button
              type="button"
              className={cn("flex-1 py-2 text-sm font-bold rounded-lg transition-colors", type === 'expense' ? "bg-white text-rose-500 shadow" : "text-slate-500 hover:bg-slate-200")}
              onClick={() => setType('expense')}
            >
              Expense
            </button>
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">Amount (৳)</label>
            <input
              type="number"
              required
              min="0"
              step="1"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 rounded-xl px-4 py-3 outline-none transition-all font-semibold"
              placeholder="e.g. 500"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Date</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 rounded-xl px-4 py-3 outline-none transition-all font-semibold"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Category)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 rounded-xl px-4 py-3 outline-none transition-all font-semibold"
              >
                {CATEGORIES.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">Note (Optional)</label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 rounded-xl px-4 py-3 outline-none transition-all font-semibold"
              placeholder="What was this for?"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-3 px-4 bg-emerald-900 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-lg shadow-emerald-900/20 transition-all flex items-center justify-center gap-2"
            >
              <PlusCircle className="w-5 h-5" />
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
