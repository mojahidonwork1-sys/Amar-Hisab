import React from 'react';
import { Transaction } from '../types';
import { formatCurrency } from '../utils/helpers';
import { cn } from '../utils/cn';
import { ArrowUpCircle, ArrowDownCircle, Wallet } from 'lucide-react';

interface DashboardOverviewProps {
  transactions: Transaction[];
}

export function DashboardOverview({ transactions }: DashboardOverviewProps) {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const currentMonthTransactions = transactions.filter(t => {
    const d = new Date(t.date);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });

  const income = currentMonthTransactions
    .filter(t => t.type === 'income')
    .reduce((acc, t) => acc + t.amount, 0);

  const expense = currentMonthTransactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => acc + t.amount, 0);

  const balance = income - expense;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
      <StatCard 
        title="Current Balance" 
        amount={balance} 
        icon={<Wallet className="w-8 h-8 text-emerald-600" />} 
        type="balance" 
      />
      <StatCard 
        title="Total Income (This Month)" 
        amount={income} 
        icon={<ArrowUpCircle className="w-8 h-8 text-emerald-500" />} 
        type="income" 
      />
      <StatCard 
        title="Total Expense (This Month)" 
        amount={expense} 
        icon={<ArrowDownCircle className="w-8 h-8 text-red-500" />} 
        type="expense" 
      />
    </div>
  );
}

function StatCard({ title, amount, icon, type }: { title: string, amount: number, icon: React.ReactNode, type: 'balance'|'income'|'expense' }) {
  if (type === 'balance') {
    return (
      <div className="bg-emerald-900 p-6 rounded-[32px] text-white shadow-xl flex flex-col justify-between h-40 transition-transform duration-300 hover:-translate-y-1">
        <span className="text-emerald-300 text-sm font-medium">{title}</span>
        <div className="text-4xl font-bold whitespace-nowrap overflow-hidden text-ellipsis">{formatCurrency(amount)}</div>
        <div className="text-xs text-emerald-400">Total balance up to date</div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-[32px] border border-slate-200 shadow-sm flex flex-col justify-between h-40 transition-transform duration-300 hover:-translate-y-1">
      <span className="text-slate-500 text-sm font-medium">{title}</span>
      <div className={cn("text-3xl lg:text-4xl font-bold whitespace-nowrap overflow-hidden text-ellipsis", type === 'income' ? 'text-emerald-600' : 'text-rose-500')}>
        {formatCurrency(amount)}
      </div>
      <div className="w-full bg-slate-100 h-1.5 rounded-full mt-2">
        <div className={cn("h-full rounded-full", type === 'income' ? 'bg-emerald-500 w-3/4' : 'bg-rose-400 w-1/3')}></div>
      </div>
    </div>
  );
}
