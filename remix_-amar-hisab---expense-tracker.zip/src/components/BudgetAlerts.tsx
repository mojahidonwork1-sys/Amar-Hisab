import React from 'react';
import { Transaction, Budget } from '../types';
import { AlertTriangle } from 'lucide-react';

interface BudgetAlertsProps {
  transactions: Transaction[];
  budgets: Budget[];
}

export function BudgetAlerts({ transactions, budgets }: BudgetAlertsProps) {
  if (budgets.length === 0) return null;

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const currentMonthExpenses = transactions.filter(t => {
    if (t.type !== 'expense') return false;
    const d = new Date(t.date);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  }).reduce((acc, t) => {
    acc[t.category] = (acc[t.category] || 0) + t.amount;
    return acc;
  }, {} as Record<string, number>);

  const alerts = budgets.map(budget => {
    const spent = currentMonthExpenses[budget.category] || 0;
    const percentage = (spent / budget.amount) * 100;
    return { ...budget, percentage };
  }).filter(b => b.percentage >= 80);

  if (alerts.length === 0) return null;

  return (
    <div className="flex flex-col gap-3">
      {alerts.map(alert => (
        <div key={alert.category} className={`flex items-center gap-3 p-4 rounded-2xl border ${alert.percentage >= 100 ? 'bg-rose-50 border-rose-200 text-rose-700' : 'bg-amber-50 border-amber-200 text-amber-700'}`}>
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${alert.percentage >= 100 ? 'bg-rose-100 text-rose-600' : 'bg-amber-100 text-amber-600'}`}>
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-sm">
              {alert.percentage >= 100 ? 'Budget Exceeded!' : 'Approaching Budget Limit'}
            </h4>
            <p className="text-xs mt-0.5 opacity-80 font-medium">
              {alert.category}: You have used {alert.percentage.toFixed(0)}% of your monthly budget.
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
