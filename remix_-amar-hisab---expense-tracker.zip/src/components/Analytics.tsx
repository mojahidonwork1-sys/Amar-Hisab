import { useMemo, useState } from 'react';
import { Transaction } from '../types';
import { formatCurrency } from '../utils/helpers';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { cn } from '../utils/cn';

const COLORS = ['#059669', '#10b981', '#34d399', '#6ee7b7', '#0f766e', '#14b8a6', '#2dd4bf', '#5eead4'];

export function Analytics({ transactions }: { transactions: Transaction[] }) {
  const [viewState, setViewState] = useState<'pie' | 'bar'>('pie');
  
  const expenseData = useMemo(() => {
    const expenses = transactions.filter(t => t.type === 'expense');
    
    const categoryTotals = expenses.reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(categoryTotals)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [transactions]);

  if (transactions.length === 0) return null;

  return (
    <div className="bg-white p-6 rounded-[32px] border border-slate-200 shadow-sm h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-bold">Spending by Category</h3>
        <div className="bg-white/60 p-1 rounded-xl flex">
            <button 
              onClick={() => setViewState('pie')}
              className={cn("px-3 py-1 text-xs font-medium rounded-lg transition-colors", viewState === 'pie' ? "bg-white shadow text-emerald-900" : "text-emerald-700 hover:bg-white/40")}
            >
              Pie
            </button>
            <button 
              onClick={() => setViewState('bar')}
              className={cn("px-3 py-1 text-xs font-medium rounded-lg transition-colors", viewState === 'bar' ? "bg-white shadow text-emerald-900" : "text-emerald-700 hover:bg-white/40")}
            >
              Bar
            </button>
        </div>
      </div>
      
      <div className="flex-1 min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          {viewState === 'pie' ? (
            <PieChart>
              <Pie
                data={expenseData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {expenseData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value: number) => formatCurrency(value)}
                contentStyle={{ borderRadius: '16px', border: 'none', backgroundColor: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(8px)', boxShadow: '0 4px 20px rgba(0,0,0,0.05)' }}
              />
              <Legend verticalAlign="bottom" height={36} iconType="circle" />
            </PieChart>
          ) : (
            <BarChart data={expenseData} margin={{ top: 20, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(16, 185, 129, 0.1)" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#064e3b' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#064e3b' }} tickFormatter={(value) => `৳${value}`} axisLine={false} tickLine={false} />
              <Tooltip 
                formatter={(value: number) => formatCurrency(value)}
                cursor={{ fill: 'rgba(16, 185, 129, 0.05)' }}
                contentStyle={{ borderRadius: '16px', border: 'none', backgroundColor: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(8px)', boxShadow: '0 4px 20px rgba(0,0,0,0.05)' }}
              />
              <Bar dataKey="value" fill="#10b981" radius={[4, 4, 0, 0]}>
                {expenseData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
}
