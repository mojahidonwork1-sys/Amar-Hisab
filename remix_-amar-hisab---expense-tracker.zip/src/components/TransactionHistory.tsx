import { useState } from 'react';
import { Transaction } from '../types';
import { formatCurrency } from '../utils/helpers';
import { cn } from '../utils/cn';
import { Search, Filter, Trash2, ArrowDownLeft, ArrowUpRight } from 'lucide-react';

interface TransactionHistoryProps {
  transactions: Transaction[];
  onDelete: (id: string) => void;
}

export function TransactionHistory({ transactions, onDelete }: TransactionHistoryProps) {
  const [filter, setFilter] = useState<'all' | 'income' | 'expense'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTransactions = transactions
    .filter(t => filter === 'all' || t.type === filter)
    .filter(t => 
      t.category.toLowerCase().includes(searchTerm.toLowerCase()) || 
      t.note.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="bg-white p-6 rounded-[32px] border border-slate-200 shadow-sm">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h3 className="text-lg font-bold">Recent Transactions</h3>
        
        <div className="flex w-full sm:w-auto gap-2">
          <div className="relative flex-1 sm:w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-600/50" />
            <input 
              type="text" 
              placeholder="Search..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/60 border-none pl-9 pr-4 py-2 rounded-xl text-sm focus:ring-2 focus:ring-emerald-200 outline-none"
            />
          </div>
          
          <div className="bg-white/60 p-1 rounded-xl flex">
            <button 
              onClick={() => setFilter('all')}
              className={cn("px-3 py-1.5 text-xs font-medium rounded-lg transition-colors", filter === 'all' ? "bg-white shadow text-emerald-900" : "text-emerald-700 hover:bg-white/40")}
            >
              All
            </button>
            <button 
              onClick={() => setFilter('income')}
              className={cn("px-3 py-1.5 text-xs font-medium rounded-lg transition-colors", filter === 'income' ? "bg-white shadow text-emerald-900" : "text-emerald-700 hover:bg-white/40")}
            >
              In
            </button>
            <button 
              onClick={() => setFilter('expense')}
              className={cn("px-3 py-1.5 text-xs font-medium rounded-lg transition-colors", filter === 'expense' ? "bg-white shadow text-emerald-900" : "text-emerald-700 hover:bg-white/40")}
            >
              Out
            </button>
          </div>
        </div>
      </div>

      <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-8 text-emerald-800/50 text-sm">
            No transactions found.
          </div>
        ) : (
          filteredTransactions.map(t => (
            <div key={t.id} className="group bg-slate-50 hover:bg-slate-100 border border-slate-100 rounded-2xl p-4 flex items-center justify-between transition-all hover:shadow-sm">
              <div className="flex items-center gap-4">
                <div className={cn("w-10 h-10 flex items-center justify-center rounded-xl flex-shrink-0 font-bold", 
                  t.type === 'income' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'
                )}>
                  {t.type === 'income' ? 'I' : 'E'}
                </div>
                <div>
                  <p className="font-semibold text-slate-900">{t.category}</p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {new Date(t.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })} 
                    {t.note && ` • ${t.note}`}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <span className={cn("font-bold", 
                  t.type === 'income' ? 'text-emerald-600' : 'text-rose-500'
                )}>
                  {t.type === 'income' ? '+ ' : '- '}{formatCurrency(t.amount)}
                </span>
                <button 
                  onClick={() => onDelete(t.id)}
                  className="opacity-0 group-hover:opacity-100 p-2 text-rose-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                  aria-label="Delete transaction"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
