import { useState } from 'react';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Transaction, UserProfile, Budget, Category } from './types';
import { Layout } from './components/Layout';
import { DashboardOverview } from './components/DashboardOverview';
import { TransactionForm } from './components/TransactionForm';
import { TransactionHistory } from './components/TransactionHistory';
import { Analytics } from './components/Analytics';
import { SmartTips } from './components/SmartTips';
import { BudgetTracker } from './components/BudgetTracker';
import { BudgetAlerts } from './components/BudgetAlerts';
import { exportToCSV } from './utils/helpers';
import { Plus } from 'lucide-react';

export default function App() {
  const [transactions, setTransactions] = useLocalStorage<Transaction[]>('amarhisab_transactions', []);
  const [profile, setProfile] = useLocalStorage<UserProfile>('amarhisab_profile', { name: 'Mujahid' });
  const [budgets, setBudgets] = useLocalStorage<Budget[]>('amarhisab_budgets', []);
  
  const [activeView, setActiveView] = useState<'dashboard' | 'history' | 'analytics' | 'budgets'>('dashboard');
  const [isAddingTransaction, setIsAddingTransaction] = useState(false);
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  const handleAddTransaction = (transaction: Transaction) => {
    setTransactions(prev => [...prev, transaction]);
    setIsAddingTransaction(false);
  };

  const handleDeleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  const handleExport = () => {
    exportToCSV(transactions, `AmarHisab_Export_${new Date().toISOString().split('T')[0]}.csv`);
  };

  const handleSetBudget = (newBudget: Budget) => {
    setBudgets(prev => {
      const existing = prev.filter(b => b.category !== newBudget.category);
      return [...existing, newBudget];
    });
  };

  const handleDeleteBudget = (category: Category) => {
    setBudgets(prev => prev.filter(b => b.category !== category));
  };

  return (
    <Layout 
      activeView={activeView} 
      setActiveView={setActiveView}
      userName={profile.name}
      onEditProfile={() => setIsEditingProfile(true)}
      onExport={handleExport}
    >
      <div className="space-y-6">
        {activeView === 'dashboard' && (
          <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
            <DashboardOverview transactions={transactions} />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <TransactionHistory 
                  transactions={transactions.slice(-5)} 
                  onDelete={handleDeleteTransaction}
                />
              </div>
              <div className="lg:col-span-1 space-y-6">
                <BudgetAlerts transactions={transactions} budgets={budgets} />
                <SmartTips transactions={transactions} />
              </div>
            </div>
          </div>
        )}

        {activeView === 'budgets' && (
          <div className="animate-in slide-in-from-bottom-4 duration-500">
            <BudgetTracker 
              transactions={transactions} 
              budgets={budgets} 
              onSetBudget={handleSetBudget}
              onDeleteBudget={handleDeleteBudget}
            />
          </div>
        )}

        {activeView === 'history' && (
          <div className="animate-in slide-in-from-bottom-4 duration-500">
            <TransactionHistory 
              transactions={transactions} 
              onDelete={handleDeleteTransaction}
            />
          </div>
        )}

        {activeView === 'analytics' && (
          <div className="animate-in slide-in-from-bottom-4 duration-500">
            <Analytics transactions={transactions} />
          </div>
        )}
      </div>

      {/* Floating Action Button for Adding Transaction */}
      <button 
        onClick={() => setIsAddingTransaction(true)}
        className="fixed bottom-20 md:bottom-8 right-4 md:right-8 w-14 h-14 bg-emerald-900 hover:bg-emerald-800 text-white rounded-full shadow-lg shadow-emerald-900/20 flex items-center justify-center transition-transform hover:scale-110 z-30"
        aria-label="Add Transaction"
      >
        <Plus className="w-6 h-6" />
      </button>

      {isAddingTransaction && (
        <TransactionForm 
          onAdd={handleAddTransaction} 
          onCancel={() => setIsAddingTransaction(false)} 
        />
      )}

      {/* Edit Profile Modal */}
      {isEditingProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-white rounded-[32px] p-8 w-full max-w-sm shadow-2xl border border-slate-200">
              <h2 className="text-xl font-bold text-slate-900 mb-4">Edit Profile</h2>
              <input 
                type="text"
                autoFocus
                value={profile.name}
                onChange={(e) => setProfile({ name: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 rounded-xl px-4 py-3 outline-none transition-all mb-4 font-semibold"
                placeholder="Your Name"
              />
              <button 
                onClick={() => setIsEditingProfile(false)}
                className="w-full py-3 bg-emerald-900 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-lg shadow-emerald-900/20 transition-all"
              >
                Save
              </button>
            </div>
        </div>
      )}
    </Layout>
  );
}
